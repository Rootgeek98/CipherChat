<?php

/**
 * Contains the database configuration in which the application would 
 * use to access the database.
 * @author Bill Glinton <tom.omuom@strathmore.edu>
 * @author Romuald Ashuza <romuald.ashuza@strathmore.edu>
 * @author Betty Kyalo <betty.kyalo@strathmore.edu>
 * @author Kelvin Kimutai<kelvinkpkrr.@gmail.com>
 */

$hostname = "localhost"; // Host

$username = "id17520261_cipher_app"; // Username

$password = "NbTWQeDA@@Mp7C7JEjM$"; // Password

$database = "id17520261_cipher_chat"; // Database Name


define("FIREBASE_API_KEY", "AAAA9-diNX8:APA91bEPwN4xRN0Vv0Yu41fRPq9qy_n3d0Tl_qhmRKYX5UImYXhxFfDsMoRbUeukIYwCEr3gSV4QLOQuJMjvJNRPQmIbWM3e7yrACxwSbLhJtm5g_EI0G2dMg2N5vqat6Ouoymw8IN3O");
 

// Push Notification Flags

define('PUSH_FLAG_CHATROOM', 1);

define('PUSH_FLAG_USER', 2);

?>
